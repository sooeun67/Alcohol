setwd("~/ANLY503/EXAM")
# Read Data
library(readr)
AlcoholConsumption <- read_csv("Data/AlcoholConsumption_bins.csv")
View(AlcoholConsumption)
library(htmlwidgets)
library(plotly)
packageVersion('plotly')

# Plotly Credentials
Sys.setenv("plotly_username"="sooeun67")
Sys.setenv("plotly_api_key"="ygxskRGTqtvpdoCyLbtP")

# Create a scatter plot
# Plot 1.
p_scatter <- plot_ly(data = AlcoholConsumption, x = ~Life_Expectancy, y = ~Good_Mental_Health_Score, 
                     color = ~BinBeer, colors = palette())
p_scatter
# Create a sharable link to plot 1
api_create(p_scatter, filename = "p_scatter")

# Plot 2.
scatter_2 <- plot_ly(data = AlcoholConsumption, x = ~Life_Expectancy, y = ~GDP_PerCapita,
                     color = ~BinWine, colors = "Accent", size = AlcoholConsumption$Good_Mental_Health_Score,
                     text = ~paste('Country: ', AlcoholConsumption$Country,
                                   "<br>Wine Consumption: ", AlcoholConsumption$Wine_PerCapita,
                                   '<br>GDP per capita: ', AlcoholConsumption$GDP_PerCapita,
                                   '<br>Life Expectancy: ', AlcoholConsumption$Life_Expectancy))
scatter_2
# Create a sharable link to plot 2
api_create(scatter_2, filename = "scatter_gdp_life_wine")




# Rotatable 3D 
#install.packages("threejs")
library(threejs)
library(igraph)
library(htmlwidgets)
library(dplyr)

AlcoholConsumption$revised_beer <- AlcoholConsumption$Beer_PerCapita/100
AlcoholConsumption$revised_wine <- AlcoholConsumption$Wine_PerCapita/100
AlcoholConsumption$revised_spirits <- AlcoholConsumption$Spirit_PerCapita/100

p2 <- plot_ly(AlcoholConsumption, x = ~revised_beer, y = ~revised_wine, z = ~revised_spirits, 
              color = ~BinLifeExpectancy, colors = c("yellow", "blue", "green", "grey", "pink") ) %>%
  add_markers() %>%
  layout(
    title = "3D Plot of Beer, Wine, Spirits colored by life expectancy",
    scene = list(xaxis = list(title = 'Beer Consumption'),
                 yaxis = list(title = 'Wine Consumption'),
                 zaxis = list(title = 'Spirits Consumption')))
p2

saveWidget(as_widget(p2), file="3D_rotatable_alcohol_plotly.html")





rotatable_3D <- scatterplot3js(AlcoholConsumption$revised_beer, AlcoholConsumption$revised_wine, 
                               AlcoholConsumption$revised_spirits,
                               color = c("yellow", "blue", "green", "grey", "pink")[as.factor(AlcoholConsumption$BinLifeExpectancy)],
                               axisLabels = c("BeerConsumption", "WineConsumption", "SpiritsConsumption")
                               )
rotatable_3D
saveWidget(rotatable_3D, file = "rotatable_3D.html", selfcontained = TRUE, libdir = NULL, background = "white")

