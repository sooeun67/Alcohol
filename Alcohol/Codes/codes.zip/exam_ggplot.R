setwd("~/ANLY503/EXAM")
# Read Data
library(readr)
AlcoholConsumption <- read_csv("Data/AlcoholConsumption.csv")
View(AlcoholConsumption)

# Bin all columns for the future use
AlcoholConsumption$BinMentalScore <- as.factor(as.numeric(cut(AlcoholConsumption$Good_Mental_Health_Score, 5)))
AlcoholConsumption$BinHDI <- as.factor(as.numeric(cut(AlcoholConsumption$HDI, 5)))
AlcoholConsumption$BinGDP <- as.factor(as.numeric(cut(AlcoholConsumption$GDP_PerCapita, 5)))
AlcoholConsumption$BinBeer <- as.factor(as.numeric(cut(AlcoholConsumption$Beer_PerCapita, 5)))
AlcoholConsumption$BinWine <- as.factor(as.numeric(cut(AlcoholConsumption$Wine_PerCapita, 5)))
AlcoholConsumption$BinSpirit <- as.factor(as.numeric(cut(AlcoholConsumption$Spirit_PerCapita, 5)))
AlcoholConsumption$BinLifeExpectancy <- as.factor(as.numeric(cut(AlcoholConsumption$Life_Expectancy, 5)))

head(AlcoholConsumption)


library(ggplot2)
library(ggthemes)

# Plot 1. 
ggplot (data=AlcoholConsumption) +
  geom_point(mapping = aes(x = Good_Mental_Health_Score, y = HDI, color = BinBeer)) +
  geom_smooth(mapping = aes(x = Good_Mental_Health_Score, y = HDI)) + 
  facet_wrap(~BinBeer, nrow = 2) + 
  ggtitle("Human Development Index(HDI), Mental Healthiness, and Beer")
  theme_classic()

ggsave("Facet_Happiness_HDI_Beer.jpg")


# Plot 2.
ggplot(data = AlcoholConsumption, aes(x = BinLifeExpectancy, y = HDI)) + 
  geom_boxplot(aes(fill = BinLifeExpectancy)) +
  geom_jitter() + 
  ggtitle("Life Expectancy and Human Development Index") +
  theme_economist()

ggsave("Boxplot_LifeExp_and_HDI.jpg")

# Plot 2-1.
ggplot(data = AlcoholConsumption, aes(x = BinLifeExpectancy, y = Beer_PerCapita)) + 
  geom_boxplot(aes(fill = BinLifeExpectancy)) +
  geom_jitter() + 
  ggtitle("Life Expectancy and Beer Consumption") +
  theme_economist()

ggsave("Boxplot_LifeExp_and_Beer.jpg")

# Plot 3.
ggplot(data = AlcoholConsumption, aes(AlcoholConsumption$HDI)) +
  geom_histogram(aes(y = ..count..),
                 col = "orange",
                 fill = "skyblue",
                 bins = 20,
                 alpha = .5) +
  geom_density(col = 4) +
  ggtitle("Histogram of Human Development Index") +
  xlab("Human Development Index") + 
  theme_solarized()

ggsave("Histogram_HDI.jpg")

# Plot 3-1
myplot <-
ggplot(data = AlcoholConsumption, aes(AlcoholConsumption$Beer_PerCapita)) +
  geom_histogram(aes(y = ..count..),
                 col = "yellow",
                 fill = "red",
                 bins = 30,
                 alpha = .5) +
  geom_density(col = 4) +
  ggtitle("Histogram of Beer Consumption") +
  xlab("Beer Consumpiton (in liters)") + 
  theme_economist()

##Using ggsave
ggsave("Histogram_Beer.jpg")


#Save ggplotly as widget -> gives interactive using plotly
library(htmlwidgets)
library(plotly)
saveWidget(ggplotly(myplot), file = "Histogram_Beer.html")


# Write my updated dataframe to a csv file
write.csv(AlcoholConsumption, 'AlcoholConsumption_bins.csv')
