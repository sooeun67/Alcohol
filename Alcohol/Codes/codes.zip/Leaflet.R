# libraries
library(rgdal)
library(leaflet)
library(maps)
library(mapdata)
library(maptools)
library(rgdal)
library(sp)
library(geojsonio)
library(viridis)
library(readr)
library(plotrix)
library("classInt")

AlcoholConsumption <- read_csv("Data/AlcoholConsumption_bins.csv")



world <- map("world", fill=TRUE, plot=FALSE)
world_map <- map2SpatialPolygons(world, sub(":.*$", "", world$names))
world_map <- SpatialPolygonsDataFrame(world_map,
                                      data.frame(country=names(world_map), 
                                                 stringsAsFactors=FALSE), 
                                      FALSE)

cnt <- c("Germany", "Ireland", "Czech Republic", "Venezuela", "Poland", "Lithuania",
         "Namibia", "Gabon", "France", "Portugal", "Russia", "Belarus", "Haiti")

target <- subset(world_map, country %in% cnt)

p <-
  leaflet(data = target) %>% 
  addTiles() %>% 
  addPolygons(weight=2) %>%
  addMarkers(lng = 29.0003377 , lat = -25.0838838, popup = "South Africa: 6.7 HDI, Low Alcohol Comsumption") %>%
  addMarkers(lng = -95.0902 , lat = 30.7129, popup = "USA: 6.7 HDI, Low Alcohol Comsumption") %>%
  addMarkers(lng = -100 , lat = 60, popup = "Canada: 9.22 HDI, Average Alcohol Comsumption") %>%
  addMarkers(lng = 80 , lat = 60, popup = "Russia: 8.15 HDI, High Alcohol Comsumption") %>%
  addPopups(lng = 29.0003377 , lat = -25.0838838,
            popup = "South Africa: 6.7 HDI, Low Alcohol Comsumption, <br> Life Expectancy: 62.7",
            options = popupOptions(closeButton = TRUE)) %>%
  addPopups(lng = -100 , lat = 60,
            popup = "Canada: 9.22 HDI, High Beer Consumption but low in wine and spirits, <br> Life Expectancy: 82.3",
            options = popupOptions(closeButton = TRUE)) %>%
  addPopups(lng = 80 , lat = 60,
            popup = "Russia: 8.15 HDI, High Alcohol Comsumption, <br> Life Expectancy: 71.7",
            options = popupOptions(closeButton = TRUE)) 


p
library(htmlwidgets)
saveWidget(p, file="leaflet_map.html")



