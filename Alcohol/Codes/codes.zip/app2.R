



setwd("~/ANLY503/EXAM")
# Read Data
library(readr)
library(rsconnect)
library(shiny)
library(devtools)
rsconnect::setAccountInfo(name='sooeunoh',
                          token='31291EC4ABCBFBE18A19D802C9BE2D11',
                          secret='wpNpoODiaYJZr4AX2mB2ZYtTnsFY0u3OWxyTnLhn')

AlcoholConsumption <- read_csv("Data/AlcoholConsumption_bins.csv")
View(AlcoholConsumption)

# Define ui
ui <- fluidPage(
  # App title
  titlePanel("Distribution of Alcohol Consumption"),
  # Sidebar layout with input and output definitions
  sidebarLayout(
    #Input: Slector
    selectInput("Alcohol", "Alcohol:",
                list("Beer" = "Beer_PerCapita",
                     "Wine" = "Wine_PerCapita",
                     "Spirits" = "Spirit_PerCapita")),
    checkboxInput("outliers", "Show outliers", TRUE)
  ),
  
  mainPanel(
    h3(textOutput("caption")),
    plotOutput("AlcoholPlot")
  )
)




AlcoholConsumption$Beer_PerCapita <- factor(AlcoholConsumption$Beer_PerCapita, 
                                            labels = c("High", "Medium", "Low"))

server <- function(input, output) {
  formulaText <- reactive({
    paste("Alcohol~", input$variable)
  })
  output$caption <- renderText({
    formulaText()
  })
  output$AlcoholPlot <- renderPlot({
    boxplot(as.formula(formulaText()),
            data = AlcoholConsumption,
            outline = input$outliers,
            col = "#75AADB", pch = 19)
    
  })
}

shinyApp(ui, server)
