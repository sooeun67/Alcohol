install.packages("tidyverse")
install.packages("plotly")
install.packages("htmlwidgets")
install.packages("ggplot2")
install.packages("tibble") #create tables
install.packages("tidyr") # pipe ?
install.packages("readr")
install.packages("purr")

#Inside the ggplot2 library, there is mpg dataset
library(ggplot2)
mpgDF <- mpg
(mpgDF) #print out mpgDF

#Column names of mpgDF
colnames(mpgDF)

#Data Structure of mpgDF
str(mpgDF)

## change to factors
# character -> factor/category conversion is important for us, because character would consider a4 as different characters.

mpgDF$manufacturer <- as.factor(mpgDF$manufacturer)
mpgDF$class <- as.factor(mpgDF$class)
mpgDF$drv <- as.factor(mpgDF$drv)
mpgDF$trans <- as.factor(mpgDF$trans)
mpgDF$fl <- as.factor(mpgDF$fl)
str(mpgDF)

ggplot(data = mpgDF)

MyPlot <- ggplot(data = mpgDF)+ geom_point(mapping = aes(x = displ, y = hwy))

##Using ggsave
ggsave("DisplHwyt.pdf")

#Save ggplotly as widget
library(ggplot2)
library(htmlwidgets)
saveWidget(ggplotly(MyPlot), file = "ggtest.html")



## Step1- give you a blank
ggplot(data = mpgDF)
## Step2 
ggplot(data = mpgDF) + geom_point(mapping = aes(x = displ, y = hwy))
## Step3 : Different color codes by factors
ggplot(data = mpgDF) + geom_point(mapping = aes(x = displ, y = hwy, color = class))

## Step 4: Use of size
ggplot(data = mpgDF) + geom_point(mapping = aes(x = displ, y = hwy, size = class))

## Step 5: Use of shape
ggplot(data = mpgDF) + geom_point(mapping = aes(x = displ, y = hwy, shape = class))

## Step 6: Use of color and size
ggplot(data = mpgDF) + geom_point(mapping = aes(x = displ, y = hwy, color = class, size = class))




