setwd("~/ANLY503/EXAM")
# libraries
library(readr)
library(shiny)
library(tm)
library(wordcloud)
library(memoise)
library(shiny)
library(tm)
library(wordcloud)
library(memoise)
library(SnowballC)
library(RColorBrewer)
library(WDI)
library(dplyr)

AlcoholConsumption <- read_csv("Data/AlcoholConsumption_bins.csv")
View(AlcoholConsumption)

beer_wordcloud <-
  wordcloud(words = AlcoholConsumption$Country, freq = AlcoholConsumption$Beer_PerCapita, min.freq = 10,
            random.order=FALSE, rot.per=0.3, scale=c(2, 0.3),
            random.color=FALSE, colors = brewer.pal(10, "Paired"))

wine_wordcloud <-
  wordcloud(words = AlcoholConsumption$Country, freq = AlcoholConsumption$Wine_PerCapita, min.freq = 10,
            random.order=FALSE, rot.per=0.3, scale=c(2, 0.3),
            random.color=FALSE, colors = brewer.pal(10, "Paired"))

spirits_wordcloud <-
  wordcloud(words = AlcoholConsumption$Country, freq = AlcoholConsumption$Spirit_PerCapita, min.freq = 10,
            random.order=FALSE, rot.per=0.3, scale=c(2, 0.3),
            random.color=FALSE, colors = brewer.pal(10, "Paired"))

